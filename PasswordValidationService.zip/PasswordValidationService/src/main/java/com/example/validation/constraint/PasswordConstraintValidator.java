package com.example.validation.constraint;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.passay.AllowedRegexRule;
import org.passay.CharacterRule;
import org.passay.EnglishCharacterData;
import org.passay.EnglishSequenceData;
import org.passay.IllegalSequenceRule;
import org.passay.LengthRule;
import org.passay.PasswordData;
import org.passay.PasswordValidator;
import org.passay.RepeatCharacterRegexRule;
import org.passay.RepeatCharactersRule;
import org.passay.RuleResult;

public class PasswordConstraintValidator implements ConstraintValidator<ValidPassword, String> {

	@Override
	public void initialize(ValidPassword arg0) {
	}

	@Override
	public boolean isValid(String password, ConstraintValidatorContext context) {
		PasswordValidator validator = new PasswordValidator(Arrays.asList(
				// at least 5 characters
				new LengthRule(5, 12),
				
				//Allowed only lower case letters and digits
				new AllowedRegexRule("^[a-z0-9]+$"),
	
		// at least one lower-case character
		 new CharacterRule(EnglishCharacterData.LowerCase, 1),

		// at least one digit character
		 new CharacterRule(EnglishCharacterData.Digit, 1),
		 
		 new RepeatCharacterRegexRule(3),
		 new RepeatCharactersRule(3,3),
		 
		 new IllegalSequenceRule(EnglishSequenceData.Numerical, 3, true),
		 new IllegalSequenceRule(EnglishSequenceData.Alphabetical, 3, true)
		 
		 // refer list of rules in http://www.passay.org/reference/

		));

		RuleResult result = validator.validate(new PasswordData(password));
		if (result.isValid()) {
			return true;
		}
		
		  List<String> messages = validator.getMessages(result);
		  String messageTemplate = messages.stream() .collect(Collectors.joining(","));
		  context.buildConstraintViolationWithTemplate(messageTemplate)
		  .addConstraintViolation() .disableDefaultConstraintViolation();
		 
		return false;
	}
}