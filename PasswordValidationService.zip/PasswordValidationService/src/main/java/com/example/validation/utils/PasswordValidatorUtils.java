package com.example.validation.utils;

public class PasswordValidatorUtils {
	
	
	public static boolean isSequencePresentInPasword(String password) {
	    final char[] array = password.toCharArray();
	    boolean flag = false;
	    for (int length = 1; length < array.length / 2; length++) {

	        for (int startIndex = 0; startIndex < array.length; startIndex++) {
	            final boolean isSequencePresentForGivenLength =
	                    isSequencePresentForGivenLength(array, startIndex, length);
	            if (isSequencePresentForGivenLength) {
	                System.out.println(
	                        " given string =" + password + ", start index =" + startIndex + ", having length" + length
	                                + ", sequence present = " + isSequencePresentForGivenLength);
	                flag = true;
	                return flag;
	            }

	        }
	        if (flag) {
	            return flag;
	        }
	    }
	    
	    if (!flag) {System.out.println("There is no sequence present");}
	    
	    return flag;
	}
	
	


	 public static boolean isSequencePresentForGivenLength(final char[] array, final int startIndexOfArray,
	            final int length) {

	        boolean isSequencePresent = false;
	        try {
	            int endIndex = startIndexOfArray + length;
	            int startIndex = startIndexOfArray;
	            final int initialEndIndex = endIndex;
	            while (startIndex != endIndex && endIndex < array.length && endIndex < (startIndexOfArray + (2 * length))) {
	                if (array[startIndex] == array[endIndex]) {
	                    startIndex++;
	                    endIndex++;
	                }
	                else {
	                    isSequencePresent = false;
	                    return isSequencePresent;
	                }
	            }

	            if (startIndex == initialEndIndex) {
	                isSequencePresent = true;
	            }

	        }
	        catch (final Exception e) {
	            e.printStackTrace();
	        }

	        return isSequencePresent;
	    }

}
