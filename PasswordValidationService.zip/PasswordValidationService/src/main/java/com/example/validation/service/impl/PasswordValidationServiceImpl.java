package com.example.validation.service.impl;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.validation.dto.RequestDto;
import com.example.validation.dto.ResponseBody;
import com.example.validation.service.PasswordValidationService;
import com.example.validation.utils.PasswordValidatorUtils;

@Service
public class PasswordValidationServiceImpl implements PasswordValidationService {

	@Override
	public ResponseEntity<ResponseBody> validatePassword(RequestDto requestDetails) {
		
		//check for any sequence of characters present
		boolean isSequencePresent = PasswordValidatorUtils.isSequencePresentInPasword(requestDetails.getPassword());
		
		if(isSequencePresent)
		{
			return ResponseEntity.ok(new ResponseBody("error", "Password validation is failed due to  sequence of characters present."));

		}else
		{
			return ResponseEntity.ok(new ResponseBody("success", "Password validation is successfull."));

		}
		
	}

}
