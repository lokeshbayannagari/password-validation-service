package com.example.validation.controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.DisplayName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.validation.dto.RequestDto;
import com.fasterxml.jackson.databind.ObjectMapper;


@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
//@ActiveProfiles(value = "test")
public class PasswordValidationControllerAPITest {



	@Autowired
	private MockMvc mockMvc;




	private static ObjectMapper mapper = new ObjectMapper();


	@Test
	 @DisplayName(" test validatePassword having only 4 characters")
	public void testValidatePassword() throws Exception {

		RequestDto  passwordrequest = new RequestDto();
		passwordrequest.setPassword("test");
		String json = mapper.writeValueAsString(passwordrequest);
		mockMvc.perform(post("/validatePassword").contentType(MediaType.APPLICATION_JSON).characterEncoding("utf-8").content(json).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is4xxClientError());

	}
	
	
	@Test
	 @DisplayName(" test validatePassword having UPPER CASE characters")
	public void testValidatePassword1() throws Exception {

		RequestDto  passwordrequest = new RequestDto();
		passwordrequest.setPassword("TEST");
		String json = mapper.writeValueAsString(passwordrequest);
		mockMvc.perform(post("/validatePassword").contentType(MediaType.APPLICATION_JSON).characterEncoding("utf-8").content(json).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is4xxClientError());

	}

	
	
	@Test
	 @DisplayName(" test validatePassword having ONLY DIGITS  characters")
	public void testValidatePassword2() throws Exception {

		RequestDto  passwordrequest = new RequestDto();
		passwordrequest.setPassword("12657");
		String json = mapper.writeValueAsString(passwordrequest);
		mockMvc.perform(post("/validatePassword").contentType(MediaType.APPLICATION_JSON).characterEncoding("utf-8").content(json).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is4xxClientError());

	}
	
	
	@Test
	 @DisplayName(" test validatePassword having ONLY lower case  characters")
	public void testValidatePassword3() throws Exception {

		RequestDto  passwordrequest = new RequestDto();
		passwordrequest.setPassword("abhe");
		String json = mapper.writeValueAsString(passwordrequest);
		mockMvc.perform(post("/validatePassword").contentType(MediaType.APPLICATION_JSON).characterEncoding("utf-8").content(json).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is4xxClientError());

	}
	
	@Test
	 @DisplayName(" test validatePassword having more than 12  characters")
	public void testValidatePassword4() throws Exception {

		RequestDto  passwordrequest = new RequestDto();
		passwordrequest.setPassword("abhe1264eyhlquopcvnka");
		String json = mapper.writeValueAsString(passwordrequest);
		mockMvc.perform(post("/validatePassword").contentType(MediaType.APPLICATION_JSON).characterEncoding("utf-8").content(json).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is4xxClientError());

	}
	
	
	@Test
	 @DisplayName(" test validatePassword having valid password")
	public void testValidatePassword5() throws Exception {

		RequestDto  passwordrequest = new RequestDto();
		passwordrequest.setPassword("abhe126");
		String json = mapper.writeValueAsString(passwordrequest);
		mockMvc.perform(post("/validatePassword").contentType(MediaType.APPLICATION_JSON).characterEncoding("utf-8").content(json).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());

	}
	
	
	@Test
	 @DisplayName(" test validatePassword having sequence of same charater repeated password")
	public void testValidatePassword6() throws Exception {

		RequestDto  passwordrequest = new RequestDto();
		passwordrequest.setPassword("abhe6cccc");
		String json = mapper.writeValueAsString(passwordrequest);
		mockMvc.perform(post("/validatePassword").contentType(MediaType.APPLICATION_JSON).characterEncoding("utf-8").content(json).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is4xxClientError());

	}
	
	
	@Test
	 @DisplayName(" test validatePassword having sequence of characters like 1234  or abcd")
	public void testValidatePassword7() throws Exception {

		RequestDto  passwordrequest = new RequestDto();
		passwordrequest.setPassword("abhe61234");
		String json = mapper.writeValueAsString(passwordrequest);
		mockMvc.perform(post("/validatePassword").contentType(MediaType.APPLICATION_JSON).characterEncoding("utf-8").content(json).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is4xxClientError());

	}


}




